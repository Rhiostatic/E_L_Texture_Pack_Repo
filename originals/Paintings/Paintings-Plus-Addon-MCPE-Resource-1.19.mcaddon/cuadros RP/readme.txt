﻿INGLES
dear user,
if you are reading this it is because you want to know how
does this addon work or do you want to modify it.
If there is something you do not understand, you can contact me by writing to me on my youtube or twitter channel,
Just asking for your subscription in exchange would help me a lot so that my addons reach more people.

For suggestions or reporting bugs write to e-mail: spartan1171346@gmail.

If you want to review my addon, I would really appreciate it if you would mention my YouTube channel. 

YOUTUBE: youtube.com/@spartan11777

TWITTER: twitter.com/SPARTAN1171346 

Thank you very much for reading, atte spartan1171346


=========================================================================================================

ESPAÑOL
querido usuario,
si estas leyendo esto es porque quieres saber como 
funciona este addon o quieres modificarlo. 
si hay algo que no entiendes puedes contactarme escribiendome en mi canal de youtube o twitter,
solo pidido a cambio tu suscripcion me ayudaria mucho para que mis addons lleguen a mas personas.

por sugerencias o reportar bugs escrir a e-mail: spartan1171346@gmail.

si quieren hacer un review de mi addon agradeceria mucho que mencionaran mi canal de youtube

YOUTUBE: youtube.com/@spartan11777

TWITTER: twitter.com/SPARTAN1171346

muchas gracias por leer, atte spartan1171346
si quieren hacer un review de mi addon agradeceria mucho que mencionaran mi canal de youtube


=========================================================================================================

PORTUGUES
querido usuário,
se você está lendo isso é porque quer saber como
este complemento funciona ou você deseja modificá-lo.
Se houver algo que você não entenda, pode entrar em contato comigo escrevendo para mim no meu canal do youtube ou twitter,
Apenas pedir sua assinatura em troca já me ajudaria muito para que meus addons cheguem a mais pessoas.

Para sugestões ou relatórios de bugs, escreva para o e-mail: spartan1171346@gmail.
Se você quiser revisar meu addon, eu agradeceria muito se você mencionasse meu canal do YouTube.

YOUTUBE: youtube.com/@spartan11777

TWITTER: twitter.com/SPARTAN1171346


Muito obrigado por ler, atte spartan1171346

